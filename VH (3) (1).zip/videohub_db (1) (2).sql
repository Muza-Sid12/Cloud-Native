-- Table structure for table `creator_tbl`
CREATE TABLE IF NOT EXISTS creator_tbl (
    Sno INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Name NVARCHAR(255) NULL,
    Email NVARCHAR(255) NULL,
    Contact TEXT NULL,
    Address TEXT NULL,
    City NVARCHAR(255) NULL,
    Gender NVARCHAR(255) NULL,
    Password NVARCHAR(255) NULL,
    Status NVARCHAR(255) NULL,
    `Date` DATE DEFAULT CURRENT_DATE
);

-- Insert data into `creator_tbl`
INSERT INTO creator_tbl (Name, Email, Contact, Address, City, Gender, Password, Status, `Date`)
SELECT 'Afan Ahmed', 'afanehmad@gmail.com', '03107551862', '155A', 'Lahore', 'Male', '11223344', 'Active', '2024-11-15'
WHERE NOT EXISTS (SELECT 1 FROM creator_tbl WHERE Email = 'afanehmad@gmail.com');

-- Table structure for table `user_tbl`
CREATE TABLE IF NOT EXISTS user_tbl (
    Sno INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Name NVARCHAR(255) NULL,
    Email NVARCHAR(255) NULL,
    Contact NVARCHAR(255) NULL,
    Address TEXT NULL,
    City NVARCHAR(255) NULL,
    Gender NVARCHAR(255) NULL,
    Password NVARCHAR(255) NULL,
    Status NVARCHAR(255) NULL,
    `Date` DATE DEFAULT CURRENT_DATE
);

-- Insert data into `user_tbl`
INSERT INTO user_tbl (Name, Email, Contact, Address, City, Gender, Password, Status, `Date`)
SELECT 'Afan Ahmed', 'afanehmad@gmail.com', '3207551861', '155A', 'Lahore', 'Male', '12345678', 'Active', '2024-11-15'
WHERE NOT EXISTS (SELECT 1 FROM user_tbl WHERE Email = 'afanehmad@gmail.com');

-- Table structure for table `video_tbl`
CREATE TABLE IF NOT EXISTS video_tbl (
    Sno INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Creator_Id NVARCHAR(255) NULL,
    Title NVARCHAR(255) NULL,
    Meta NVARCHAR(255) NULL,
    Hashtag1 NVARCHAR(255) NULL,
    Hashtag2 NVARCHAR(255) NULL,
    Hashtag3 NVARCHAR(255) NULL,
    Hashtag4 NVARCHAR(255) NULL,
    Status NVARCHAR(255) NULL,
    `Date` DATE DEFAULT CURRENT_DATE,
    Video NVARCHAR(255) NULL
);

-- Select all data from creator_tbl for testing
SELECT * FROM creator_tbl;
