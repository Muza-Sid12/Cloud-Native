<?php
   include_once'connect_db.php';
   session_start();
	$search_result="";
   if(isset($_POST['search'])){
		$search_result=$_POST['search'];
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>   
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">	
	<style>
        body {
            background-color: #f8f9fa;
            color: #495057;
            padding-top: 56px;
        }
		
		@media screen and (max-width: 580px) {
			#videosection{
				margin-top: 120px;
				padding: 10px;
			}
			.btn{
				width: 210px;
				margin-top:10px;
			}
			form{
			width:98%;
			}
		}
		@media screen and (min-width: 580px) {
			#videosection{
				margin-top: 15px;
				padding:20px;
			}
		}
		
        .navbar {
            background-color: #343a40;
			margin-bottom: 100px;
        }

        .navbar-brand, .navbar-nav .nav-link {
            color: #ffffff !important;
        }

        .about-sma-container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 20px;
        }

        .about-sma-container h2 {
            color: #343a40;
        }

        .about-sma-container p {
            color: #6c757d;
        }
        video {
			width: 100%;
			height: auto;
		}
		.fa {
			font-size: 30px;
			cursor: pointer;
			user-select: none;
			margin-right:10px;
			margin-left:10px;
		}

		.fa:hover {
			color: darkblue;
		}
		
		
		
    </style>
</head>
<body class="bg-light">

	<?php
    include("header.php");
    ?>
	<?php
	
	if(isset($_SESSION['user_id'])){
		$select = $pdo->prepare("SELECT * FROM video_tbl where Title LIKE '%$search_result%'");
        $select->execute();
			$i=0;			
        while($row=$select->fetch(PDO::FETCH_OBJ)){
			$i++;
	?>
    <!-- Consumer Section -->
    <section id="videosection">
        <center>
        <video autoplay="autoplay" controls style="width:30%;">
			<source src="video/<?php echo $row->Video; ?>" type="video/mp4">
			<source src="video/<?php echo $row->Video; ?>" type="video/ogg">
			Your browser does not support HTML5 video.
		</video><br>
		<h3 style="float:center;"><?php echo $row->Title; ?></h3>
		
		<i  style="float:center;" class="fa fa-comment"></i>
		<i  style="float:center;" onclick="myFunction(this)" class="fa fa-thumbs-up"></i>
		</center>
   </section>
	<br><br>
	<?php
		}
	
								
								if($i==0){
									?>
									<section class="core-features-area core-features-style-two">
									<div class="container">
									<div class="core-features-content">
                                       <br><br><br><br><br>
                                        <span>No Results Found.</span>
										<br><br><br><br><br><br>
                                    </div>
                                    </div>
									</section>
									<?php
									
								}
							
	}
		else{
	?>					
	 <section id="videosection">
        <br><br><br><br>
        <h2>Please <a href="login.php">Login</a> to Watch Videos.<h2>
		<br><br>
	</section>
	
	
	
	<?php
		}
		
	?>
	<br>
    
<br><br>
<script>
function myFunction(x) {
  x.classList.toggle("fa-thumbs-down");
}
</script>
<footer>
    <?php
    include("footer.php");
    ?>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	<script>
	
	document.addEventListener("DOMContentLoaded", function () {
  // Select all video elements within the #videosection
  const videos = document.querySelectorAll("#videosection video");

  // Create an Intersection Observer
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      const video = entry.target;

      // If the video is intersecting (in view), play it. Otherwise, pause it.
      if (entry.isIntersecting) {
        video.play();
      } else {
        video.pause();
      }
    });
  }, {
    threshold: 0.75, // 75% of the video should be visible to play
  });

  // Observe each video inside the #videosection
  videos.forEach((video) => {
    observer.observe(video);
  });
});

	
	</script>
</body>
</html>
