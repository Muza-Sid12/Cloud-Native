<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand text-danger" href="index.php">VIDEO HUB</a>
        
		
		<form class="d-flex" method="POST" action="search-results.php"  enctype="multipart/form-data" autocomplete="off">
			<input class="form-control me-2" type="search" name="search" placeholder="Search Video By Title" aria-label="Search" style="width:400px;">
			<button class="btn btn-outline-success" type="submit">Search</button>
		</form>
		
        <ul class="navbar-nav">
        <li class="nav-item px-2">
		<?php
				if(isset($_SESSION['user_id'])){
				?>
				<a href="user-dashboard.php" class="btn btn-outline-success nav-link text-light">Dashboard</a>
				
				<?php
				}
				else{
					?>
					<a href="login.php" class="btn btn-outline-success nav-link text-light" style="float:left;">User Login</a>
					<a href="creator_login.php" class="btn btn-outline-success nav-link text-light" style="float:left;margin-left:10px;">Creator Login</a>
					<?php
				}
		?>
            
			
        </li>
        </ul>
    
    </div>
    </nav>