<?php
   include_once'connect_db.php';
   session_start();
   
   if(!isset($_SESSION['creator_id'])){
	  
		echo "<script>if(confirm('Please Login to Continue.')){document.location.href='creator_login.php'};</script>";
    
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>    <style>
        /* Custom CSS for the About SMA section */
        body {
            background-color: #f8f9fa;
            color: #495057;
            padding-top: 56px;
        }

        .navbar {
            background-color: #343a40;
        }

        .navbar-brand, .navbar-nav .nav-link {
            color: #ffffff !important;
        }

        .about-sma-container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 20px;
        }

        .about-sma-container h2 {
            color: #343a40;
        }

        .about-sma-container p {
            color: #6c757d;
        }
        
    </style>
</head>
<body class="bg-light">
    <?php
    include("header-user.php");
    ?>

    

    <!-- Mobile Registration and Information Section -->
    <section class="container mt-4">
	<div class="d-flex flex-column align-items-center">
	
	
    
        <h2 class="text-center mb-1">Welcome to Video Hub Creator Dashboard</h2>
        <br><br>
        <a href="upload_video.php"><button class="btn btn-outline-success text-dark mb-1" href="">Add new Video</button></a>
        <a href="creator_videos.php"><button class="btn btn-outline-success text-dark mb-1" href="">View My Videos</button></a>
    </div>
</section>
<br><br>
<footer>
    <?php
    include("footer.php");
    ?>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
