<?php
   include_once'connect_db.php';
   session_start();
   
   if(!isset($_SESSION['creator_id'])){
	  
	 echo "<script>if(confirm('Please Login to Continue.')){document.location.href='login.php'};</script>";
    
   }
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>    
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
        
		/* Custom CSS for the About SMA section */
        body {
            background-color: #f8f9fa;
            color: #495057;
            padding-top: 56px;
        }

        .navbar {
            background-color: #343a40;
        }

        .navbar-brand, .navbar-nav .nav-link {
            color: #ffffff !important;
        }

        .about-sma-container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 20px;
        }

        .about-sma-container h2 {
            color: #343a40;
        }

        .about-sma-container p {
            color: #6c757d;
        }
        .container {
  padding: 2rem 0rem;
}

h4 {
  margin: 2rem 0rem 1rem;
}

.table-image {
  td, th {
    vertical-align: middle;
  }
}
    </style>
</head>
<body class="bg-light">
    <?php
    include("header-user.php");
    ?>

    

    <!-- Mobile Registration and Information Section -->
    <section class="container mt-4">
	<div class="d-flex flex-column align-items-center">
	
	
    
        <h2 class="text-center mb-1">Your Listing</h2>
        <a href="creator-dashboard.php"><p><b>Go Back</b></p></a>
        <div class="container">
  <div class="row">
    <div class="col-12">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Meta</th>
            <th scope="col">Tags</th>
            <th scope="col">Status</th>
            <th scope="col">Date</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
		
		<?php
		$user_id="";
			if(isset($_SESSION['creator_id'])){
				
				$user_id=$_SESSION['creator_id'];
			}
			$sum = 0;
				$select = $pdo->prepare("SELECT * FROM video_tbl where Creator_Id='$user_id'");
						$select->execute();
						while($row=$select->fetch(PDO::FETCH_OBJ)){
							$sum = $sum + 1;
		?>
          <tr>
            <th scope="row"><?php echo $sum; ?></th>
            <td><?php echo $row->Title; ?></td>
            <td><?php echo $row->Meta; ?></td>
            <td><?php echo $row->Hashtag1; ?>, <?php echo $row->Hashtag2; ?>, <?php echo $row->Hashtag3; ?>, <?php echo $row->Hashtag4; ?></td>
            <td><?php echo $row->Status; ?></td>
            <td><?php echo $row->Date; ?></td>
            <td>
              <a href="delete.php?id=<?php echo $row->Sno; ?>"><button type="button" class="btn btn-danger"><i class="fa fa-trash"></i></button></a>
            </td>
          </tr>
          <?php
			}
		  ?>
          
        </tbody>
      </table>
    </div>
  </div>
</div>

    </div>
</section>
<br><br>
<footer>
    <?php
    include("footer.php");
    ?>
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
