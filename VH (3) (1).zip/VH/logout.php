<?php

session_start(); 


  	session_destroy();
  	unset($_SESSION['user_id']);
  	unset($_SESSION['name']);
  	unset($_SESSION['email']);
  	unset($_SESSION['creator_id']);
  	unset($_SESSION['creator_name']);
  	unset($_SESSION['creator_email']);
  	
	header('location:index.php');
  
?>