<?php
// Redirect to VH directory
header("Location: /VH/");
exit();
?>